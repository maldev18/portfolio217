


let slideIndex = 0;
showSlides();

function showSlides() {
    let slides = document.getElementsByClassName("mySlides");
    for (let i = 0; i < slides.length; i++) {
        slides[i].style.display = "none";  
    }
    slideIndex++;
    if (slideIndex > slides.length) {slideIndex = 1}    
    slides[slideIndex-1].style.display = "block";  
    setTimeout(showSlides, 4000); // Change image every 5 seconds
}

// Get elements
const loginBtn = document.getElementById("form-open");
const loginModal = document.getElementById("loginModal");
const signupModal = document.getElementById("signupModal");
const closeBtns = document.querySelectorAll(".closeBtn");
const signupLink = document.getElementById("signupLink");

// Show Login Modal
loginBtn.onclick = function() {
    loginModal.style.display = "block";
}

// Show Signup Modal
signupLink.onclick = function() {
    loginModal.style.display = "none";
    signupModal.style.display = "block";
}

// Close Modals
closeBtns.forEach(btn => {
    btn.onclick = function() {
        btn.closest(".modal").style.display = "none";
    }
});

// Close Modals when clicking outside of them
window.onclick = function(event) {
    if (event.target == loginModal) {
        loginModal.style.display = "none";
    } else if (event.target == signupModal) {
        signupModal.style.display = "none";
    }
}





